	<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand visible-xs-block visible-sm-block" href="index.php">Inicio</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav ">
					<li><a href="index.php">Listado empleados</a></li>
					<li><a href="add.php">Agregar Empleado</a></li>
					<li><a href="clientes.php">Listado Abonados</a></li>
					<li class="active"><a href="cadd.php">Agregar Abonado</a></li>
					<li><a href="logica/salir.php">Salir</a></li>
					
				</ul>
			</div><!--/.nav-collapse -->
	</div>